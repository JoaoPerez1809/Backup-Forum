# Etapa atual
Criamos os models e as migrações

# Comandos para criação do banco
php artisan migrate:reset
php artisan make:migration alter_users_table
php artisan make:migration create_posts_table
php artisan make:migration create_rates_table
php artisan make:migration create_categories_table
php artisan make:migration create_topics_table
php artisan make:migration create_comments_table
php artisan make:migration create_tags_table
php artisan make:migration create_topic_tags_table