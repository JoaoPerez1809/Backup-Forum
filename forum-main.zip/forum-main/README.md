Projeto para a criação de um forum ficticio, Tendo feito no dia 26/06/2024 a parte de gerenciamento com o usuario por exemplo login,cadastro,perfil etc.
Tendo as partes de autenticações para não ter acessos indevidos em certas partes.
Vai ser adicionado a parte de topicos para usuarios poderem interagir tendo a criação do proprio topico, comentarios entre esses usuarios, geralmente oque tem nos foruns.

Integrantes:
João Vitor Perez Saraiva
Gabriel Sales Dorea
