@extends('layouts.gpt')

@section('header', 'Listar Todos os Usuários')

@section('content')
    <table border="1">
        <tr>
            <td>Nome</td>
            <td>Email</td>
        </th>
        <tr>
            <td>Fulano</td>
            <td>fulano@email.com</td>
        </th>
</table>
@endsection